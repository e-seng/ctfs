#!/usr/bin/bash
cd /ctf
./registration
